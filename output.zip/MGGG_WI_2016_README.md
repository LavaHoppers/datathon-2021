# Wisconsin Election Shapefile
This shapefile was processed by members of the Voting Rights Data Institute. The Voting Rights Data Institute (VRDI) was a 2018 summer intensive sponsored by the Metric Geometry and Gerrymandering Group (MGGG) at Tufts and MIT, with major support from a Bose Research Grant at MIT and from the Jonathon M. Tisch College of Civic Life at Tufts.

## Sources
The wards shapefile with election data comes from the Wisconsin State Legislature and is available for download on the [LTSB Open Data Page](https://data-ltsb.opendata.arcgis.com). This shapefile contains the 2011 wards which were in place during the 2012 to 2016 elections. 

## Processing
The state of Wisconsin reports their election data at the level of ward groups. The LTSB disaggregates the data from the reported unit to wards using voting age population, or rather the population over the age of 18 according to the 2010 US Census (for further explanation of the LTSB methods see [here](https://www.arcgis.com/home/item.html?id=62d5782482cd45f2898fe7e3d4272c10)). MGGG and its partners are currently working to disaggregate votes using voting eligible population to take into account factors such as incarcerated people or noncitizens who cannot vote.

The raw shapefile downloaded from the LTSB data portal contains many topology errors that made it impossible to use it to run [MGGG's Markov chain](https://gerrychain.readthedocs.io/en/latest/). The script [check_shapefile_connectivity.py](https://github.com/gerrymandr/Preprocessing) was run to fix these topology errors.

## Metadata
Below is a brief description of each of the listed variables in the attribute table of the ward shapefile:
- `GEOID10`: Ward FIPS code
- `OBJECTID`: Ward identifier
- `NAME`: Ward name
- `ASM`: State assembly district number
- `SEN`: State senate district number
- `CON`: Congressional district number
- `CNTY_NAME`: County name
- `PERSONS`: Population from 2010 Census
- `WHITE`: White population from 2010 Census
- `BLACK`: Black/African American population from 2010 Census
- `HISPANIC`: Population of Hispanic origin from 2010 Census
- `ASIAN`: Asian population from 2010 Census
- `AMINDIAN`: American Indian or Alaska Native population from 2010 Census
- `PISLAND`: Native Hawaiian or other Pacific Islander population from 2010 Census
- `OTHER`: Population of other race from 2010 Census
- `OTHERMLT`: Population of other multiple races from 2010 Census
- `PERSONS18`: Population over the age of 18 from the 2010 Census
- `WHITE18`: White population over 18 from the 2010 Census
- `BLACK 18`: Black population over 18 from the 2010 Census
- `HISPANIC18`: Population of Hispanic origin over 18 from the 2010 Census
- `ASIAN18`: Asian population over 18 from the 2010 Census
- `AMINDIAN18`: American Indian or Alaska Native population over 18 from the 2010 Census
- `PISLAND18`: Native Hawaiian or other Pacific Islander population over 18 from the 2010 Census
- `OTHER18`: Population of other race over 18 from the 2010 Census
- `OTHERMLT18`: Population of other multiple races over 18 from the 2010 Census
- `CDATOT16`: Total number of votes for County District Attorney in 2016 election
- `CDADEM16`: Number of votes for 2016 Democratic candidate for County District Attorney
- `CDAREP16`: Number of votes for 2016 Republican candidate for County District Attorney
- `CDAIND16`: Number of votes for 2016 Independent candidate for County District Attorney
- `CDASCT16`: Number of votes for 2016 scatter candidates for County District Attorney
- `PRETOT16`: Total number of votes for President in 2016 election
- `PREDEM16`: Number of votes for 2016 Democratic presidential candidate
- `PREREP16`: Number of votes for 2016 Republican presidential candidate
- `PREGRN16`: Number of votes for 2016 Green Party presidential candidate
- `PRELIB16`: Number of votes for 2016 Libertarian presidential candidate
- `PRECON16`: Number of votes for 2016 Congressional Party presidential candidate
- `PREIND16`: Number of votes for 2016 Independent presidential candidate
- `PREIND216`: Number of votes for 2016 second Independent presidential candidate
- `PREIND316`: Number of votes for 2016 third Independent presidential candidate
- `PREIND416`: Number of votes for 2016 fourth Independent presidential candidate
- `PREIND516`: Number of votes for 2016 fifth Independent presidential candidate
- `PREIND616`: Number of votes for 2016 sixth Independent presidential candidate
- `PREIND716`: Number of votes for 2016 seventh Independent presidential candidate
- `PREIND816`: Number of votes for 2016 eighth Independent presidential candidate
- `PREIND916`: Number of votes for 2016 ninth Independent presidential candidate
- `PREIND1016`: Number of votes for 2016 tenth Independent presidential candidate
- `PREIND1116`: Number of votes for 2016 eleventh Independent presidential candidate
- `PRESCT16`: Number of votes for 2016 scatter presidential candidates
- `USHTOT16`: Total number of votes for US House in 2016 election
- `USHDEM16`: Number of votes for 2016 Democratic house candidate
- `USHDEM216`: Number of votes for 2016 second Democratic house candidate
- `USHREP216`: Number of votes for 2016 second Republican house candidate
- `USHREP16`: Number of votes for 2016 Republican house candidate
- `USHGRN16`: Number of votes for 2016 Green Party house candidate
- `USHLIB16`: Number of votes for 2016 Libertarian house candidate
- `USHIND16`: Number of votes for 2016 Independent house candidate
- `USHSCT16`: Number of votes for 2016 scatter house candidates
- `USSTOT16`: Total number of votes for US Senate in 2016 election
- `USSDEM16`: Number of votes for 2016 Democratic senate candidate
- `USSREP16`: Number of votes for 2016 Republican senate candidate
- `USSREP216`:  Number of votes for 2016 second Republican senate candidate
- `USSLIB16`:  Number of votes for 2016 Libertarian senate candidate
- `USSSCT16`:  Number of votes for 2016 scatter senate candidates
- `WSATOT16`: Total number of votes for WI State Assembly in 2016 election
- `WSADEM16`: Number of votes for 2016 Democratic state assembly candidate
- `WSAREP16`: Number of votes for 2016 Republican state assembly candidate
- `WSALIB16`: Number of votes for 2016 Libertarian state assembly candidate
- `WSAIND16`: Number of votes for 2016 Independent state assembly candidate
- `WSASCT16`: Number of votes for 2016 scatter state assembly candidates
- `WSSTOT16`: Total number of votes for WI State Senate in 2016 election
- `WSSDEM16`: Number of votes for 2016 Democratic state senate candidate
- `WSSREP16`: Number of votes for 2016 Republican state senate candidate
- `WSSIND16`: Number of votes for 2016 Independent state senate candidate
- `WSSSCT16`: Number of votes for 2016 scatter state senate candidates
- `GOVTOT14`: Total number of votes for Governor in 2014 election
- `GOVDEM14`: Number of votes for 2014 Democratic gubernatorial candidate
- `GOVREP14`: Number of votes for 2014 Republican gubernatorial candidate
- `GOVREP214`: Number of votes for 2014 second Republican gubernatorial candidate
- `GOVREP314`: Number of votes for 2014 third Republican gubernatorial candidate
- `GOVCON14`: Number of votes for 2014 Congressional Party gubernatorial candidate
- `GOVIND14`: Number of votes for 2014 Independent gubernatorial candidate
- `GOVIND214`: Number of votes for 2014 second Independent gubernatorial candidate
- `GOVIND314`: Number of votes for 2014 third Independent gubernatorial candidate
- `GOVIND414`: Number of votes for 2014 fourth Independent gubernatorial candidate
- `GOVIND514`: Number of votes for 2014 fifth Independent gubernatorial candidate
- `GOVSCT14`: Number of votes for 2014 scatter gubernatorial candidates
- `SOSTOT14`: Total number of votes for WI Secretary of State in 2014 election
- `SOSDEM14`: Number of votes for 2014 Democratic secretary of state candidate
- `SOSREP14`: Number of votes for 2014 Republican secretary of state candidate
- `SOSCON14`: Number of votes for 2014 Congressional Party secretary of state candidate
- `SOSIND14`: Number of votes for 2014 Independent secretary of state candidate
- `SOSSCT14`: Number of votes for 2014 scatter secretary of state candidates
- `TRSTOT14`: Total number of votes for WI Treasurer in 2014 election
- `TRSDEM14`: Number of votes for 2014 Democratic treasurer candidate
- `TRSREP14`: Number of votes for 2014 Republican treasurer candidate
- `TRSCON14`: Number of votes for 2014 Congressional Party treasurer candidate
- `TRSIND14`: Number of votes for 2014 Independent treasurer candidate
- `TRSIND214`: Number of votes for 2014 second Independent treasurer candidate
- `TRSSCT14`: Number of votes for 2014 scatter treasurer candidates
- `USHTOT14`: Total number of votes for US House in 2014 election
- `USHDEM14`: Number of votes for 2014 Democratic house candidate
- `USHREP14`: Number of votes for 2014 Republican house candidate
- `USHREP214`: Number of votes for 2014 second Republican house candidate
- `USHIND14`: Number of votes for 2014 Independent house candidate
- `USHIND214`: Number of votes for 2014 second Independent house candidate
- `USHSCT14`: Number of votes for 2014 scatter house candidates
- `USSTOT14`: Total number of votes for WI State Senate in 2014 election
- `USSDEM14`: Number of votes for 2014 Democratic state senate candidate
- `USSREP14`: Number of votes for 2014 Republican state senate candidate
- `USSIND14`: Number of votes for 2014 Independent state senate candidate
- `USSSCT14`: Number of votes for 2014 scatter state senate candidates
- `WAGTOT14`: Total number of votes for WI Attorney General in 2014 election
- `WAGDEM14`: Number of votes for 2014 Democratic attorney general candidate
- `WAGREP14`: Number of votes for 2014 Republican attorney general candidate
- `WAGIND14`: Number of votes for 2014 Independent attorney general candidate
- `WAGSCT14`: Number of votes for 2014 scatter attorney general candidates
- `WSATOT14`:  Total number of votes for WI State Assembly in 2014 election
- `WSADEM14`: Number of votes for 2014 Democratic state assembly candidate
- `WSAREP14`: Number of votes for 2014 Republican state assembly candidate
- `WSAREP214`: Number of votes for 2014 second Republican state assembly candidate
- `WSAIND14`: Number of votes for 2014 Independent state assembly candidate
- `WSASCT14`: Number of votes for 2014 scatter state assembly candidates
- `CDATOT12`: Total number of votes for County District Attorney in 2012 election
- `CDADEM12`: Number of votes for 2012 Democratic candidate for County District Attorney
- `CDADEM212`: Number of votes for 2012 second Democratic candidate for County District Attorney
- `CDAREP12`: Number of votes for 2012 Republican candidate for County District Attorney
- `CDAIND12`: Number of votes for 2012 Independent candidate for County District Attorney
- `CDASCT12`: Number of votes for 2012 scatter candidates for County District Attorney
- `GOVTOT12`: Total number of votes for Governor in 2012 election
- `GOVDEM12`: Number of votes for 2012 Democratic gubernatorial candidate
- `GOVREP12`: Number of votes for 2012 Republican gubernatorial candidate
- `GOVIND12`: Number of votes for 2012 Independent gubernatorial candidate
- `GOVSCT12`: Number of votes for 2012 scatter gubernatorial candidates
- `PRETOT12`: Total number of votes for President in 2012 election
- `PREDEM12`: Number of votes for 2012 Democratic presidential candidate
- `PREREP12`: Number of votes for 2012 Republican presidential candidate
- `PRECON12`: Number of votes for 2012 Congressional Party presidential candidate
- `PREIND12`: Number of votes for 2012 Independent presidential candidate
- `PREIND212`: Number of votes for 2012 second Independent presidential candidate
- `PREIND312`: Number of votes for 2012 third Independent presidential candidate
- `PREIND412`: Number of votes for 2012 fourth Independent presidential candidate
- `PREIND512`: Number of votes for 2012 fifth Independent presidential candidate
- `PREIND612`: Number of votes for 2012 sixth Independent presidential candidate
- `PRESCT12`: Number of votes for 2012 scatter presidential candidates
- `USHTOT12`: Total number of votes for US House in 2012 election
- `USHDEM12`: Number of votes for 2012 Democratic house candidate
- `USHREP12`: Number of votes for 2012 Republican house candidate
- `USHIND12`: Number of votes for 2012 Independent house candidate
- `USHSCT12`: Number of votes for 2012 scatter house candidates
- `USSTOT12`: Total number of votes for US Senate in 2012 election
- `USSDEM12`: Number of votes for 2012 Democratic senate candidate
- `USSREP12`: Number of votes for 2012 Republican senate candidate
- `USSCON12`: Number of votes for 2012 Congressional Party senate candidate
- `USSIND12`: Number of votes for 2012 Independent senate candidate
- `USSIND212`: Number of votes for 2012 second Independent senate candidate
- `USSIND312`: Number of votes for 2012 third Independent senate candidate
- `USSSCT12`: Number of votes for 2012 scatter senate candidates
- `WAGTOT12`: Total number of votes for WI Attorney General in 2012 election
- `WAGDEM12`: Number of votes for 2012 Democratic attorney general candidate
- `WAGDEM212`: Number of votes for 2012 second Democratic attorney general candidate
- `WAGREP12`: Number of votes for 2012 Republican attorney general candidate
- `WAGIND12`: Number of votes for 2012 Independent attorney general candidate
- `WAGSCT12`: Number of votes for 2012 scatter attorney general candidates
- `WSATOT12`: Total number of votes for WI State Assembly in 2012 election
- `WSADEM12`: Number of votes for 2012 Democratic state assembly candidate
- `WSADEM212`: Number of votes for 2012 second Democratic state assembly candidate
- `WSAREP12`: Number of votes for 2012 Republican state assembly candidate
- `WSAREP212`: Number of votes for 2012 second Republican state assembly candidate
- `WSAIND12`: Number of votes for 2012 Independent state assembly candidate
- `WSAIND212`: Number of votes for 2012 second Independent state assembly candidate
- `WSASCT12`: Number of votes for 2012 scatter state assembly candidates
- `WSSTOT12`: Total number of votes for WI State Senate in 2012 election
- `WSSDEM12`: Number of votes for 2012 Democratic state senate candidate
- `WSSREP12`: Number of votes for 2012 Republican state senate candidate
- `WSSREP212`: Number of votes for 2012 second Republican state senate candidate
- `WSSCON12`: Number of votes for 2012 Congressional Party state senate candidate
- `WSSIND12`: Number of votes for 2012 Independent state senate candidate
- `WSSSCT12`: Number of votes for 2012 scatter state senate candidates
- `WSSAME12`: Number of votes for 2012 America First Party state senate candidate

NOTE: The shapefile has results for 2014 that use the LTSB code for US Senate (USS). This is a mistake that the LTSB has fixed in later versions of this shapefile. There was no US Senate election in Wisconsin in 2014. These are the results for the Wisconsin state senate. This is reflected in the descriptions of the variables.

## Projection
The shapefile uses a NAD83 UTM zone 16 N (or EPSG:26916) projection.

## Rating
We give this shapefile a B rating. Wisconsin's Legislative Technology Services Bureau (LTSB) disaggregates election data from ward groups to wards using voting age population rather than voting eligible population. The use of voting age population to disaggregate results can be misleading particularly in wards with a large population of people who are over 18, but are incarcerated and thus not eligible to vote. MGGG and its collaborators are currently working to create a wards shapefile dissagregated by voting eligible population.


___
# Election Shapefile Verification Report
MGGG's WI 2016

[Open Precincts Verification Script](https://github.com/OpenPrecincts/verification)

[Verification Report Breakdown](https://github.com/OpenPrecincts/verification#verification-report-fields)
## Statewide Reports

### Quality Scores:
|                                                                                                            |                |
|:-----------------------------------------------------------------------------------------------------------|---------------:|
| [vote_score](https://github.com/OpenPrecincts/verification#vote-score)                                     |    1.00056     |
| [county_vote_score_dispersion](https://github.com/OpenPrecincts/verification#county-vote-score-dispersion) | 3847.07        |
| [worst_county_vote_score](https://github.com/OpenPrecincts/verification#vote-score)                        |    1.01523     |
| [median_county_area_difference_score](https://github.com/OpenPrecincts/verification#area-difference-score) |    0.000790006 |
| [worst_county_area_difference_score](https://github.com/OpenPrecincts/verification#area-difference-score)  |    0.241103    |

### Library Compatibility:
|                    |    |
|:-------------------|---:|
| can_use_maup       |  ✅ |
| can_use_gerrychain |  ✅ |

## Raw Data:
|                               |           |
|:------------------------------|:----------|
| all_precincts_have_a_geometry | ✅        |
| n_votes_democrat_expected     | 1381823.0 |
| n_votes_republican_expected   | 1404440.0 |
| n_two_party_votes_expected    | 2786263.0 |
| n_votes_democrat_observed     | 1382536   |
| n_votes_republican_observed   | 1405284   |
| n_two_party_votes_observed    | 2787820   |

## County Level Reports
|   geoid | name               |   vote_score |   area_difference_score |   n_votes_democrat_expected |   n_votes_republican_expected |   n_two_party_votes_expected |   n_votes_democrat_observed |   n_votes_republican_observed |   n_two_party_votes_observed |
|--------:|:-------------------|-------------:|------------------------:|----------------------------:|------------------------------:|-----------------------------:|----------------------------:|------------------------------:|-----------------------------:|
|   55001 | Adams County       |     0.995694 |             0.00501377  |                        3770 |                          5983 |                         9753 |                        3745 |                          5966 |                         9711 |
|   55003 | Ashland County     |     0.999867 |             0.0046461   |                        4228 |                          3302 |                         7530 |                        4226 |                          3303 |                         7529 |
|   55005 | Barron County      |     1.00084  |             0.000425793 |                        7879 |                         13606 |                        21485 |                        7889 |                         13614 |                        21503 |
|   55007 | Bayfield County    |     0.99978  |             0.00136085  |                        4954 |                          4125 |                         9079 |                        4953 |                          4124 |                         9077 |
|   55009 | Brown County       |     1.00025  |             0.00474831  |                       53364 |                         67199 |                       120563 |                       53382 |                         67211 |                       120593 |
|   55011 | Buffalo County     |     0.997872 |             0.000689399 |                        2531 |                          4049 |                         6580 |                        2522 |                          4044 |                         6566 |
|   55013 | Burnett County     |     0.99988  |             0.000943728 |                        2948 |                          5412 |                         8360 |                        2949 |                          5410 |                         8359 |
|   55015 | Calumet County     |     1.0006   |             0.241103    |                        9646 |                         15348 |                        24994 |                        9642 |                         15367 |                        25009 |
|   55017 | Chippewa County    |     1.00027  |             0.000392044 |                       11886 |                         17909 |                        29795 |                       11887 |                         17916 |                        29803 |
|   55019 | Clark County       |     1        |             0.00043707  |                        4227 |                          8646 |                        12873 |                        4221 |                          8652 |                        12873 |
|   55021 | Columbia County    |     1.00018  |             0.000634239 |                       13526 |                         14160 |                        27686 |                       13528 |                         14163 |                        27691 |
|   55023 | Crawford County    |     0.998074 |             0.00042396  |                        3425 |                          3844 |                         7269 |                        3419 |                          3836 |                         7255 |
|   55025 | Dane County        |     1.00058  |             0.00127777  |                      217526 |                         71279 |                       288805 |                      217697 |                         71275 |                       288972 |
|   55027 | Dodge County       |     0.999803 |             0.000452791 |                       13968 |                         26643 |                        40611 |                       13968 |                         26635 |                        40603 |
|   55029 | Door County        |     0.999037 |             0.0210702   |                        8026 |                          8584 |                        16610 |                        8014 |                          8580 |                        16594 |
|   55031 | Douglas County     |     1.00067  |             0.0080813   |                       11345 |                          9659 |                        21004 |                       11357 |                          9661 |                        21018 |
|   55033 | Dunn County        |     1.00029  |             0.000338525 |                        9026 |                         11488 |                        20514 |                        9034 |                         11486 |                        20520 |
|   55035 | Eau Claire County  |     1.0013   |             0.000601433 |                       27294 |                         23311 |                        50605 |                       27340 |                         23331 |                        50671 |
|   55037 | Florence County    |     1        |             0.00127338  |                         666 |                          1897 |                         2563 |                         665 |                          1898 |                         2563 |
|   55039 | Fond du Lac County |     0.999463 |             0.054058    |                       17391 |                         31044 |                        48435 |                       17387 |                         31022 |                        48409 |
|   55041 | Forest County      |     0.998628 |             0.000918573 |                        1584 |                          2788 |                         4372 |                        1579 |                          2787 |                         4366 |
|   55043 | Grant County       |     1.00027  |             0.00040025  |                       10046 |                         12349 |                        22395 |                       10051 |                         12350 |                        22401 |
|   55045 | Green County       |     1        |             0.000536547 |                        9122 |                          8693 |                        17815 |                        9122 |                          8693 |                        17815 |
|   55047 | Green Lake County  |     0.999439 |             0.00101883  |                        2701 |                          6213 |                         8914 |                        2693 |                          6216 |                         8909 |
|   55049 | Iowa County        |     1        |             0.0004685   |                        6669 |                          4809 |                        11478 |                        6669 |                          4809 |                        11478 |
|   55051 | Iron County        |     0.997919 |             0.00109854  |                        1273 |                          2090 |                         3363 |                        1275 |                          2081 |                         3356 |
|   55053 | Jackson County     |     0.999542 |             0.00121396  |                        3821 |                          4907 |                         8728 |                        3818 |                          4906 |                         8724 |
|   55055 | Jefferson County   |     1.00038  |             0.000453127 |                       16561 |                         23410 |                        39971 |                       16569 |                         23417 |                        39986 |
|   55057 | Juneau County      |     1.00063  |             0.00438048  |                        4073 |                          7123 |                        11196 |                        4073 |                          7130 |                        11203 |
|   55059 | Kenosha County     |     1.00058  |             0.00273512  |                       35771 |                         36025 |                        71796 |                       35800 |                         36038 |                        71838 |
|   55061 | Kewaunee County    |     1.00059  |             0.00145882  |                        3623 |                          6616 |                        10239 |                        3627 |                          6618 |                        10245 |
|   55063 | La Crosse County   |     0.999813 |             0.000878581 |                       32406 |                         26389 |                        58795 |                       32406 |                         26378 |                        58784 |
|   55065 | Lafayette County   |     1        |             0.00039904  |                        3288 |                          3977 |                         7265 |                        3288 |                          3977 |                         7265 |
|   55067 | Langlade County    |     1.0033   |             0.000622861 |                        3260 |                          6436 |                         9696 |                        3250 |                          6478 |                         9728 |
|   55069 | Lincoln County     |     1.00015  |             0.000622776 |                        5370 |                          8400 |                        13770 |                        5371 |                          8401 |                        13772 |
|   55071 | Manitowoc County   |     1.0022   |             0.000979213 |                       14506 |                         23193 |                        37699 |                       14538 |                         23244 |                        37782 |
|   55073 | Marathon County    |     1.00005  |             0.000341195 |                       26477 |                         39013 |                        65490 |                       26480 |                         39013 |                        65493 |
|   55075 | Marinette County   |     1.01523  |             0.00141852  |                        6243 |                         12995 |                        19238 |                        6409 |                         13122 |                        19531 |
|   55077 | Marquette County   |     0.999202 |             0.000868711 |                        2809 |                          4714 |                         7523 |                        2808 |                          4709 |                         7517 |
|   55078 | Menominee County   |     0.997642 |             0.000628319 |                        1003 |                           269 |                         1272 |                        1002 |                           267 |                         1269 |
|   55079 | Milwaukee County   |     1.0006   |             0.00391725  |                      288797 |                        125846 |                       414643 |                      288822 |                        126069 |                       414891 |
|   55131 | Washington County  |     1.00011  |             0.00069069  |                       20855 |                         51729 |                        72584 |                       20852 |                         51740 |                        72592 |
|   55133 | Waukesha County    |     1.00021  |             0.000466774 |                       79200 |                        142521 |                       221721 |                       79224 |                        142543 |                       221767 |
|   55081 | Monroe County      |     1.00038  |             0.000984415 |                        7048 |                         11352 |                        18400 |                        7051 |                         11356 |                        18407 |
|   55083 | Oconto County      |     1.00768  |             0.00129659  |                        5884 |                         13253 |                        19137 |                        5940 |                         13344 |                        19284 |
|   55085 | Oneida County      |     1.00099  |             0.00109538  |                        8104 |                         12117 |                        20221 |                        8109 |                         12132 |                        20241 |
|   55087 | Outagamie County   |     0.999727 |             0.000477612 |                       38087 |                         49884 |                        87971 |                       38068 |                         49879 |                        87947 |
|   55089 | Ozaukee County     |     1.00071  |             0.00266998  |                       20168 |                         30430 |                        50598 |                       20170 |                         30464 |                        50634 |
|   55091 | Pepin County       |     0.999718 |             0.000756813 |                        1345 |                          2206 |                         3551 |                        1344 |                          2206 |                         3550 |
|   55093 | Pierce County      |     1.00158  |             0.0011288   |                        8382 |                         11258 |                        19640 |                        8399 |                         11272 |                        19671 |
|   55095 | Polk County        |     0.999532 |             0.000707186 |                        7570 |                         13815 |                        21385 |                        7565 |                         13810 |                        21375 |
|   55097 | Portage County     |     1.0002   |             0.000555806 |                       18521 |                         17306 |                        35827 |                       18529 |                         17305 |                        35834 |
|   55099 | Price County       |     0.999309 |             0.000942264 |                        2669 |                          4562 |                         7231 |                        2667 |                          4559 |                         7226 |
|   55101 | Racine County      |     1.00223  |             0.000951627 |                       42512 |                         46611 |                        89123 |                       42641 |                         46681 |                        89322 |
|   55103 | Richland County    |     0.997632 |             0.000322674 |                        3577 |                          4023 |                         7600 |                        3569 |                          4013 |                         7582 |
|   55105 | Rock County        |     1.00001  |             0.000414205 |                       39343 |                         31488 |                        70831 |                       39339 |                         31493 |                        70832 |
|   55107 | Rusk County        |     1        |             0.000589637 |                        2171 |                          4564 |                         6735 |                        2171 |                          4564 |                         6735 |
|   55109 | St. Croix County   |     0.999954 |             0.000494502 |                       17486 |                         26220 |                        43706 |                       17482 |                         26222 |                        43704 |
|   55111 | Sauk County        |     1.0002   |             0.00144666  |                       14692 |                         14791 |                        29483 |                       14690 |                         14799 |                        29489 |
|   55113 | Sawyer County      |     1.00023  |             0.000742999 |                        3504 |                          5185 |                         8689 |                        3504 |                          5187 |                         8691 |
|   55115 | Shawano County     |     1.00218  |             0.000473626 |                        6056 |                         12742 |                        18798 |                        6069 |                         12770 |                        18839 |
|   55117 | Sheboygan County   |     1.0018   |             0.000894162 |                       22956 |                         32458 |                        55414 |                       23000 |                         32514 |                        55514 |
|   55119 | Taylor County      |     0.998331 |             0.000967608 |                        2398 |                          6589 |                         8987 |                        2393 |                          6579 |                         8972 |
|   55121 | Trempealeau County |     1.00069  |             0.000841466 |                        5636 |                          7364 |                        13000 |                        5639 |                          7370 |                        13009 |
|   55123 | Vernon County      |     1.0021   |             0.000516164 |                        6352 |                          6996 |                        13348 |                        6372 |                          7004 |                        13376 |
|   55125 | Vilas County       |     0.999768 |             0.000823198 |                        4770 |                          8169 |                        12939 |                        4770 |                          8166 |                        12936 |
|   55127 | Walworth County    |     1.00029  |             0.000522065 |                       18706 |                         28851 |                        47557 |                       18709 |                         28862 |                        47571 |
|   55129 | Washburn County    |     1.00311  |             0.000606425 |                        3284 |                          5404 |                         8688 |                        3281 |                          5434 |                         8715 |
|   55135 | Waupaca County     |     1.00126  |             0.000727384 |                        8440 |                         16189 |                        24629 |                        8451 |                         16209 |                        24660 |
|   55137 | Waushara County    |     0.999738 |             0.00054211  |                        3792 |                          7669 |                        11461 |                        3791 |                          7667 |                        11458 |
|   55139 | Winnebago County   |     0.999876 |             0.186798    |                       37054 |                         43448 |                        80502 |                       37047 |                         43445 |                        80492 |
|   55141 | Wood County        |     0.999664 |             0.000621472 |                       14232 |                         21503 |                        35735 |                       14225 |                         21498 |                        35723 |
