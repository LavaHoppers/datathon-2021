This file was obtained via OpenPrecincts.org and is licensed in the public domain.

WI_Wards_12_16.cpg
    - hwheelen 


WI_Wards_12_16.dbf
    - hwheelen 


WI_Wards_12_16.prj
    - hwheelen 


WI_Wards_12_16.qpj
    - hwheelen 


WI_Wards_12_16.shp
    - hwheelen 


WI_Wards_12_16.shx
    - hwheelen 


MGGG_WI_2016_README.md
    -  



